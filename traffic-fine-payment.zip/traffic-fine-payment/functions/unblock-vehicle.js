exports.handler = async function(event, context) {
    // CORS headers
    const headers = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'POST, OPTIONS'
    };

    // Handle preflight OPTIONS request
    if (event.httpMethod === 'OPTIONS') {
        return {
            statusCode: 200,
            headers,
            body: ''
        };
    }

    if (event.httpMethod === 'POST') {
        try {
            const data = JSON.parse(event.body);
            const { plate, action } = data;

            console.log(`Received ${action} command for vehicle: ${plate}`);

            // Here you would typically:
            // 1. Send command to ESP32
            // 2. Update database
            // 3. Log the action

            return {
                statusCode: 200,
                headers,
                body: JSON.stringify({
                    success: true,
                    message: `Vehicle ${plate} ${action}ed successfully`,
                    plate: plate,
                    action: action,
                    timestamp: new Date().toISOString()
                })
            };
        } catch (error) {
            return {
                statusCode: 500,
                headers,
                body: JSON.stringify({
                    success: false,
                    error: error.message
                })
            };
        }
    }

    return {
        statusCode: 405,
        headers,
        body: JSON.stringify({ error: 'Method not allowed' })
    };
};